import {operateIncomingRequests,operateAcceptPopup} from './accept-dom.mjs';
export function createAcceptBridge(browser,identity,post,popupFocused=async()=>false,now=Date.now){
 let busy=false,epoch=0,active=null;
 async function stop(resolveUnknown=false){epoch++;const saved=(await browser.storage.session.get('acceptRun')).acceptRun;let r=active??saved;if(!r&&resolveUnknown){const previous=await post('status_work',{});if(previous.id&&['ready','claimed','armed','uncertain'].includes(previous.state))r={id:previous.id};}if(!r)return {state:'idle',message:'진행 중인 수락 작업 없음'};const v=await post('stop',{id:r.id});await browser.storage.session.remove('acceptRun');active=null;return {...v,message:v.state==='uncertain'?'결과 불확실 · 웹에서 확인 필요':'수락 실행 중단·완료 상태 확인'};}
 async function status(){const r=await post('status_work',{});return {...r,message:r.state==='succeeded'?'완료 · 수락 확인 결과를 웹에 저장했습니다.':r.state==='uncertain'?'결과 불확실 · 다시 수락하지 말고 웹에서 확인하세요.':`수락 상태: ${r.state}`};}
 async function start(checkOnly=false,options={}){
  if(busy)throw Error('이미 수락 작업을 처리하고 있습니다.');busy=true;const version=epoch;let detach=()=>{},offered=false;
  try{
   const who=await identity(),tabs=await browser.tabs.query({active:true,currentWindow:true});if(tabs.length!==1)throw Error('본인 받은 신청 관리 화면을 열어 주세요.');const tab=tabs[0];
   const current=async()=>{const who2=await identity(),[t,...rest]=await browser.tabs.query({active:true,currentWindow:true}),w=await browser.windows.get(tab.windowId);if(version!==epoch||who2.deviceId!==who.deviceId||who2.blogId!==who.blogId||rest.length||t?.id!==tab.id||t?.url!==tab.url||t?.windowId!==tab.windowId||w.state==='minimized'||(!w.focused&&!await popupFocused(tab.windowId)))throw Error('현재 계정·신청 화면·브라우저 창을 유지해 주세요.');};
   const moved=info=>{if(info.windowId===tab.windowId&&info.tabId!==tab.id)epoch++;},updated=(id,change)=>{if(id===tab.id&&change.url&&change.url!==tab.url)epoch++;};browser.tabs.onActivated?.addListener(moved);browser.tabs.onUpdated?.addListener(updated);detach=()=>{browser.tabs.onActivated?.removeListener(moved);browser.tabs.onUpdated?.removeListener(updated);};
   await current();offered=true;let r=await post(checkOnly?'offer_check':options.scheduled?'scheduled_offer':'offer_work',{request_id:crypto.randomUUID(),url:tab.url});if(r.phase==='idle')return {...r,message:checkOnly?'확인할 불확정 수락 작업이 없습니다.':r.reason?'웹 주기 대기 · 현재 계정의 검토 완료 수락 작업을 확인합니다.':'현재 계정의 검토 완료 수락 작업이 없습니다.'};
   if(r.phase!==(checkOnly?'check':'inspect')||r.job?.actorId!==who.blogId||!r.nonce)throw Error('수락 대상 확인 실패');const job=r.job,profile=r.profile;active={id:r.id,deviceId:who.deviceId};await browser.storage.session.set({acceptRun:active});let frame;
   const inspect=async(operation,validUntil)=>{await current();const results=await browser.scripting.executeScript({target:frame===undefined?{tabId:tab.id,allFrames:true}:{tabId:tab.id,frameIds:[frame]},world:'ISOLATED',func:operateIncomingRequests,args:[{operation,job,profile,validUntil}]});if(operation!=='apply')await current();/* Naver's own window takes focus the moment the row is clicked. */if(frame===undefined){const matches=results.filter(x=>x.result?.accountId===job.accountId&&x.result?.actorId===job.actorId&&x.result?.requestId===job.requestId&&x.result?.neighborId===job.neighborId);if(matches.length!==1||!Number.isInteger(matches[0].frameId))throw Error('수락 화면을 하나로 확인하지 못했습니다.');frame=matches[0].frameId;return matches[0].result;}if(results.length!==1||results[0].frameId!==frame)throw Error('수락 화면 변경');return results[0].result;};
   if(checkOnly){const checked=await post('reconcile',{id:active.id,nonce:r.nonce,snapshot:await inspect('verify')});await browser.storage.session.remove('acceptRun');active=null;return {...checked,message:checked.state==='succeeded'?'확인 완료 · 현재 서로이웃 상태를 결과에 저장했습니다. 자동 실행은 꺼져 있습니다.':'현재 신청 대기 상태만으로 이전 결과를 확정할 수 없습니다. 다시 수락하지 않습니다.'};}
   r=await post('inspect',{id:active.id,nonce:r.nonce,snapshot:await inspect('inspect')});if(r.phase!=='recheck'||!r.nonce)throw Error('수락 준비 실패');
   r=await post('arm',{id:active.id,nonce:r.nonce,snapshot:await inspect('inspect')});if(r.phase!=='apply'||!r.nonce||Date.parse(r.validUntil)<=now())throw Error('수락 허가 실패');
   await current();const {acceptAttempts={}}=await browser.storage.session.get('acceptAttempts'),attempts=Object.fromEntries(Object.entries(acceptAttempts).filter(([,deadline])=>deadline>now()));if(Object.hasOwn(attempts,job.id)||Object.keys(attempts).length>=1000)throw Error('이미 시도한 수락 작업입니다.');attempts[job.id]=Date.parse(job.expiresAt);await browser.storage.session.set({acceptAttempts:attempts});
   const attempted_at=now();if(await inspect('apply',r.validUntil)!==true)throw Error('수락 시도 결과 미확인');let effect,popupId;
   if(profile.acceptPopupPath){
    const wait=ms=>new Promise(done=>setTimeout(done,ms)),inPopup=async(id,operation)=>(await browser.scripting.executeScript({target:{tabId:id},world:'ISOLATED',func:operateAcceptPopup,args:[{operation,job,profile}]}))[0]?.result;
    const pattern='https://admin.blog.naver.com'+profile.acceptPopupPath+'*',ours=t=>{try{const q=new URL(t.url).searchParams;return q.get('blogId')===job.actorId&&q.get('targetBlogId')===job.neighborId&&q.get('acceptyn')==='true';}catch{return false;}};
    for(let i=0;i<40&&popupId===undefined&&version===epoch;i++){const found=(await browser.tabs.query({url:pattern})).filter(ours);if(found.length>1)throw Error('수락 창이 여러 개 열려 있습니다.');if(found.length===1&&found[0].status==='complete')popupId=found[0].id;else await wait(150);}
    if(popupId===undefined)throw Error('네이버 수락 창을 확인하지 못했습니다.');
    await wait(700+Math.floor(Math.random()*700));if(version!==epoch)throw Error('수락 실행 중단');
    if((await inPopup(popupId,'confirm'))?.clicked!==true)throw Error('네이버 수락 창의 대상을 확인하지 못했습니다.');
    let done=false;for(let i=0;i<40&&!done;i++){await wait(200);try{done=(await inPopup(popupId,'result'))?.done===true;}catch{/* The window is between pages. */}}
    if(!done)throw Error('네이버 수락 완료 문구를 확인하지 못했습니다.');
    effect={accountId:job.accountId,actorId:job.actorId,checkedAt:now(),restriction:'none',requestId:job.requestId,neighborId:job.neighborId,state:'mutual'};
   }else effect=await inspect('verify');
   const result=await post('effect',{id:active.id,nonce:r.nonce,snapshot:effect,attempted_at});if(popupId!==undefined){await browser.tabs.remove(popupId).catch(()=>{});await browser.tabs.reload(tab.id).catch(()=>{});}if(result.state!=='succeeded'||result.scheduleState==='paused')throw Error('수락 결과 저장 또는 다음 주기 확인 필요');await browser.storage.session.remove('acceptRun');active=null;return {...result,message:'완료 · 수락 확인 결과를 웹에 저장했습니다.'};
  }catch(e){try{await stop(offered);}catch{}throw Error(`${e?.message??'수락 결과 미확인'} 자동으로 다시 수락하지 않습니다. 웹 기록을 확인하세요.`);}finally{detach();busy=false;}
 }
 return {start:options=>start(false,options),check:()=>start(true),stop,status};
}
